/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w7.lab.kyleo;

import java.util.*;

/**
 *
 * @author angel
 */
public class W7LabKyleO {

    public static void main(String[] args) {

        int max = 100;
        int min = 10;
        int range = max - min + 1;

        LinkedList<Integer> list = new LinkedList<>();
        for (int i = 0; i < 2; i++) {
            int make = (int) (Math.random() * range) + min;

            list.add(make);
        }
        
        System.out.println("First list: ");
        System.out.println(list);
        System.out.println();
        
        System.out.print("Max value in list: ");
        System.out.println(findMax(list));
        System.out.print("Min value in list: ");
        System.out.println(findMin(list));
        
        System.out.println();
        int total = findMax(list) + findMin(list);
        
        list.add(total);
        
        System.out.println("New list: ");
        System.out.println(list);
        

    }
    
    public static Integer findMin(LinkedList<Integer> list) {
        Integer min = Integer.MAX_VALUE;
        for (Integer i : list) {
            if (min > i) {
                min = i;
            }
        }
        return min;
    }
    
    public static Integer findMax(LinkedList<Integer> list) {
        Integer max = Integer.MIN_VALUE;
        for (Integer i : list) {
            if (max < i) {
                max = i;
            }
        }
        return max;
    }

}
