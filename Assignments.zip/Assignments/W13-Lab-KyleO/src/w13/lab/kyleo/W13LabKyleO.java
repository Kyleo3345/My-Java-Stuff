/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w13.lab.kyleo;

import java.util.*;

/**
 *
 * @author angel
 */
public class W13LabKyleO {


    public static void main(String[] args) {
//getting number of vertices from user
        Scanner input = new Scanner(System.in);
        System.out.println("Enter number of vertices");
        int vertices = input.nextInt();
        int[][] graph = new int[vertices][vertices];

        Graph obj = new Graph(graph, vertices);
        obj.addEdge(graph, vertices);//add edge
        obj.addEdge(graph, vertices);//add edge
        obj.printEdges(graph, vertices);//print edges
    }
}

class Graph
{
    Graph(int[][] graph, int vertices) {
//add 0's to the graph[][] initially
//later add 1 for every edge
        for (int i = 0; i < vertices; i++) {
            for (int j = 0; j < vertices; j++) {
                graph[i][j] = 0;
            }
        }
    }
//method to display edges in the graph

    void printEdges(int[][] graph, int vertices) {
        System.out.println("\n Displaying Edges:\n");
        for (int i = 0; i < vertices; i++) {
            for (int j = 0; j < vertices; j++) {
                if (graph[i][j] == 1) {
                    System.out.println(i + "->" + j);
                }
            }
        }
    }
//method to add a new edge

    void addEdge(int[][] graph, int vertices) {
//prompt for a new edge
        Scanner input = new Scanner(System.in);
        System.out.println("Enter starting node of the edge:");
        int start = input.nextInt();
        System.out.println("Enter ending node of the edge:");
        int end = input.nextInt();
//adding edge into the graph
        graph[start][end] = 1;
        graph[end][start] = 1;
    }
}