/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w1.lab.kyleo;

import java.util.Stack;
import java.util.Scanner;

/**
 *
 * @author angel
 */
public class W1LabKyleO {
    
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter how many numbers you want to place on the Stack: ");
        int stackSize = scan.nextInt();
        Stack<Integer> s = new Stack<>();
        
        System.out.println("What are your integers?");
        
        for(int i = 0; i < stackSize; i++) {
            int intStack = scan.nextInt();
            s.push(intStack);
        }
        System.out.println(" ");
        
        while (!(s.isEmpty())) {
            System.out.println(s.pop());
        }
    }
}
