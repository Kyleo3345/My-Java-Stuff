/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w5.lab.kyleo;

/**
 *
 * @author angel
 */
public class W5LabKyleO {

    public static void main(String[] args) {
        SetADT set = new ArraySet(5);
        set.add(5);
        set.add(44);
        set.add(6);
        set.add(8);
        set.add(568);

        System.out.println("element removed: " + set.remove(44));
        System.out.println("The set is Empty: " + set.isEmpty());
        System.out.println("The set size is: " + set.size());
        System.out.println("");
        System.out.println("Contains 4: " + set.contains(4));
        System.out.println("The set elements are: " + set.toString());
    }
}

class ArraySet implements SetADT {

    public static final int DEF_CAP = 10;
    public int Not_Found;
    public int count;
    public Integer[] contents;

    public static int has_next_i = 0;
    public static int next_i = 0;

    public ArraySet() 
    {
        contents = new Integer[DEF_CAP];
    }

    public ArraySet(int r) 
    {
        contents = new Integer[r];
    }

    @Override
    public void add(int e) 
    {
        for (int i = 0; i < contents.length; i++) {
            if (contents[i] == null) {
                contents[i] = e;
                break;
            }
        }
    }
    
    @Override
    public int remove(int e) 
    {
        for (int i = 0; i < contents.length; i++) {
            if (contents[i] != null && contents[i] == e) {
                contents[i] = null;
                break;
            }
        }
        return e;
    }
    
    @Override
    public boolean equals() 
    {
        return false;
    }

    @Override
    public boolean isEmpty() 
    {
        return this.size() <= 0;
    }

    @Override
    public int size() 
    {
        count = 0;
        for (Integer content : contents) {
            if (content != null) {
                count++;
            }
        }
        return count;
    }

    @Override
    public boolean contains(int e) 
    {
        Not_Found = 0;
        for (Integer content : contents) {
            if (content != null && content == e) {
                Not_Found = 1;
            }
        }
        return Not_Found == 1;
    }

    @Override
    public String toString() 
    {
        String res = "";
        while (this.hasNext()) {
            res = res.trim() + " " + this.next().toString();
        }
        return res;
    }

    public boolean hasNext() 
    {
        if (isEmpty()) {
            return false;
        }
        Not_Found = 0;
        while (has_next_i < contents.length) {
            if (contents[has_next_i] != null) {
                Not_Found = 1;
                break;
            }
        }
        has_next_i = has_next_i + 1;
        return Not_Found == 1;
    }

    public Integer next() 
    {
        Integer ele = null;
        while (next_i < contents.length) {
            if (contents[next_i] != null) {
                ele = contents[next_i];
                break;
            }
        }
        next_i = next_i + 1;
        return ele;
    }
}
