/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w10.lab.kyleo;

import java.util.*;

public class W10LabKyleO {

    public static void main(String[] args) {
        BST obj = new BST(); 
        Node r = null;
        
        // insert nodes in tree
		r=obj.insert(r,5); 
		r=obj.insert(r,4); 
		r=obj.insert(r,3); 
		r=obj.insert(r,8); 
		r=obj.insert(r,12); 
		r=obj.insert(r,7); 
		
		System.out.println("Inorder representation of tree:"); 
		obj.inorder(r); 
		System.out.println("\nSize of tree: "+obj.size(r));
		System.out.println("Leaves of tree is even or odd: "+obj.getNumberOfLeaves(r));
    }
}

class Node { 
	int data; 
	Node left, right; 

	public Node(int v) { 
		data = v; 
		left = right = null; 
	} 
} 

class BST { 

	Node insert(Node r, int v) { 

		if (r == null) { 
			r = new Node(v); 
			return r; 
		} 

		if (v < r.data) 
			r.left = insert(r.left, v); 
		else if (v > r.data) 
			r.right = insert(r.right, v); 
		return r; 
	} 

    public Node search(Node r, int k) 
    { 
        if (r==null || r.data==k) 
            return r; 
    
        if (r.data > k) 
            return search(r.left, k); 
  
        return search(r.right, k); 
    }
    
    int size(Node n) 
    { 
        if (n == null) 
            return 0; 
        else
            return(size(n.left) + 1 + size(n.right)); 
    } 
    
    String getNumberOfLeaves(Node n) 
    { 
        if (n == null) 
        { 
            return "even"; 
        } 
        Queue<Node> q = new LinkedList<>(); 
  
        int count = 0; 
        q.add(n); 
        while (!q.isEmpty())  
        { 
            Node temp = q.peek(); 
            q.poll(); 
  
            if (temp.left != null)  
            { 
                q.add(temp.left); 
            } 
            if (temp.right != null) 
            { 
                q.add(temp.right); 
            } 
            if (temp.left == null && temp.right == null)  
            { 
                count++; 
            } 
        } 
        if(count%2==0)
            return "even";
        return "odd";
    } 
	void inorder(Node r) { 
		if (r != null) { 
			inorder(r.left); 
			System.out.print(r.data+" "); 
			inorder(r.right); 
		} 
	}
}
