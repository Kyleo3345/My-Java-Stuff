/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package w12.lab.kyleo;

import java.util.*;
import java.lang.*;

public class MyGraph<V> extends UnweightedGraph<V> {
    public MyGraph() {
	}
    
	public MyGraph(List<V> vertices, List<Edge> edges) {
		super(vertices, edges);
	}

	public MyGraph(V[] vertices, int[][] edges) {
		super(vertices, edges);
	}

	public MyGraph(List<Edge> edges, int numberOfVertices) {
		super(edges, numberOfVertices);
	}

	public MyGraph(int[][] edges, int numberOfVertices) {
		super(edges, numberOfVertices);
	}

    MyGraph(int[][] edges, String[] vertices) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

	public List<List<Integer>> getConnectedComponents() {
		List<List<Integer>> components = new ArrayList<>();
		List<Integer> v = new ArrayList<>(vertices.size());
		for (int i = 0; i < vertices.size(); i++)
			v.add(i);

		getConnectedComponents(v, components);
		return components;
	}

	public void getConnectedComponents(
			List<Integer> v, List<List<Integer>> components) {
		if (v.size() > 0) {
			List<Integer> c = dfs(v.get(0)).getSearchOrder();
			components.add(c);
			v.removeAll(c);
			getConnectedComponents(v, components);
		}
	}
}
