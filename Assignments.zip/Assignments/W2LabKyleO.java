/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w2.lab.kyleo;
import java.util.Scanner;

/**
 *
 * @author angel
 */

public class W2LabKyleO {
    
    public static void reverse(int arr[], int start, int end) {
        if(start >= end)
            return;
        
        int temp;
        
        temp = arr[start];
        arr[start] = arr[end];
        arr[end] = temp;
        
        reverse(arr, start+1, end-1);
    }
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter Array size: ");
        int a = scan.nextInt();
        
        int arr[] = new int[a];
        
        System.out.println("Enter Array values ");
        
        for(int i = 0; i < a; i++) {
            arr[i] = scan.nextInt();
        }
        reverse(arr, 0, a-1);
        System.out.println("Reversed: ");
        for(int i = 0; i < a; i++){
            System.out.println(arr[i]);
        }
        
    }
}
