/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inheritance.kyleo;

import java.util.*;

/**
 *
 * @author angel
 */
public class Dog extends Pet implements Boardable {
    
    private final String size;
    public int startMonth;
    public int startDay;
    public int startYear;
    public int endMonth;
    public int endDay;
    public int endYear;
    
    public Dog(String name, String ownerName, String color, String size) {
        super(name, ownerName, color);
        this.size = size;
    }
    
    @Override
    public void setBoardStart(int month, int day, int year) {
        this.startMonth = month;
        this.startDay = day;
        this.startYear = year;
    }

    @Override
    public void setBoardEnd(int month, int day, int year) {
        this.endMonth = month;
        this.endDay = day;
        this.endYear = year;
    }

    @Override
    public boolean boarding(int month, int day, int year) {

        Calendar c = Calendar.getInstance();
        c.set(year, month, day, 0, 0);
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        Date testDate = c.getTime();

        Calendar c1 = Calendar.getInstance();
        c1.set(startYear, startMonth, startDay, 0, 0);
        c1.set(Calendar.HOUR_OF_DAY, 0);
        c1.set(Calendar.MINUTE, 0);
        c1.set(Calendar.SECOND, 0);
        c1.set(Calendar.MILLISECOND, 0);
        Date startDate = c1.getTime();

        Calendar c2 = Calendar.getInstance();
        c2.set(endYear, endMonth, endDay, 0, 0);
        c2.set(Calendar.HOUR_OF_DAY, 0);
        c2.set(Calendar.MINUTE, 0);
        c2.set(Calendar.SECOND, 0);
        c2.set(Calendar.MILLISECOND, 0);
        Date endDate = c2.getTime();
        return ((testDate.after(startDate) && testDate.before(endDate))
                || testDate.equals(startDate) || testDate.equals(endDate));

    }
    
    public String getSize() {
        return size;
    }
    
    @Override
    public String toString() {
        return "Dog:" + "\n" + getPetName() + " owned by " + getOwnerName()
                + "\nColor: " + getColor() + "\nSex: " + getGender() + "\nHair: "
                + getSize();
    }
            
}
