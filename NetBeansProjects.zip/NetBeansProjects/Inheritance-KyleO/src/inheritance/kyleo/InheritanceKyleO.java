/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inheritance.kyleo;
import java.util.*;
import java.io.*;

/**
*Program: Inheritance
*This: InheritanceKyleO.java
*Author: Kyle Osterman
*Date: 22-Feb-2024
 */
public class InheritanceKyleO {
    //Main method//
    public static void main(String[] args) {
        AnimalHospital hospital = new AnimalHospital("pets.txt");       
   
   System.out.println("Animal Hospital Information:");
   hospital. printHospitalInfo();
   
   System.out.println("Pets Named Spot");
   hospital.printPetInfoByName("Spot");
   System.out.println("");
        
   System.out.println("Pets Owned by James");
   hospital.printPetInfoByOwner("James");
   System.out.println("");
       
   System.out.println("Pets Currently Boarded");
   hospital.printPetsBoarding(1, 14, 2021);

    } 
}
