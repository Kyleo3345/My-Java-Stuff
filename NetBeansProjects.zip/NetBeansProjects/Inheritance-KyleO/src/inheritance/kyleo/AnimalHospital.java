/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inheritance.kyleo;
import java.io.*;
import java.util.*;

/**
 *
 * @author angel
 */
public class AnimalHospital {
    private final String HOSPITAL_NAME;
    private final int MAX_CAP;
    private final double DEFAULT_TREATMENT_COST;
    private final String[] ACCEPTED_ANIMAL_CATEGORIES;
    
    private List<Pet> pets = new ArrayList<>();
    
    public AnimalHospital(String inputFile) {
        HOSPITAL_NAME = "Animal Hospital";
        MAX_CAP = 100;
        DEFAULT_TREATMENT_COST = 50.0;
        ACCEPTED_ANIMAL_CATEGORIES = new String[] {"CAT", "DOG"};
        
        Scanner scan = new Scanner("pets.txt");
        String line = null;
        while (!line.equals("END")) {
            line = scan.nextLine();
            String name, owner, color, gender, size, hair;
            
            if (line.equals("PET")) {
                name = scan.nextLine();
                owner = scan.nextLine();
                color = scan.nextLine();
                gender = scan.nextLine();
                Pet p = new Pet(name, owner, color);
                if (gender.equals("Male")) {
                    p.setGender(0);
                }else {
                    p.setGender(1);
                }
                pets.add(p);
            }else if (line.equals("CAT")) {
                name = scan.nextLine();
                owner = scan.nextLine();
                color = scan.nextLine();
                gender = scan.nextLine();
                hair = scan.nextLine();
                Cat c = new Cat(name, owner, color, hair);
                if (gender.equals("Male")) {
                    c.setGender(0);
                }else {
                    c.setGender(1);
                }
            }else if (line.equals("DOG")) {
                name = scan.nextLine();
                owner = scan.nextLine();
                color = scan.nextLine();
                gender = scan.nextLine();
                size = scan.nextLine();
                Dog d = new Dog(name, owner, color, size);
                if (gender.equals("Male")) {
                    d.setGender(0);
                }else {
                    d.setGender(1);
                }
            }
        }
    }
    
    public void printPetInfoByName(String name) {
        for (Pet pet : pets) {
            if (pet.getPetName().equals(name)) {
                System.out.println(pet.toString());
            }
        }
    }
    
    public void printPetInfoByOwner(String name) {
        for (Pet pet : pets) {
            if (pet.getOwnerName().equals(name)) {
                System.out.println(pet.toString());
            }
        }
    }
    
    public void printPetsBoarding(int month, int day, int year) {
        for (Pet pet : pets) {
            if (pet instanceof Boardable) {
                Boardable boardablePet = (Boardable) pet;
                if (boardablePet.boarding(month, day, year)) {
                    System.out.println(pet.toString());
                }
            }
        }
    }

    public void printHospitalInfo() {
        System.out.println("Hospital Name: " + HOSPITAL_NAME);
        System.out.println("Max Capacity: " + MAX_CAP);
        System.out.println("Default Treatment Cost: " + DEFAULT_TREATMENT_COST);
        System.out.println("Accepted Animal Categories:");
        for (String category : ACCEPTED_ANIMAL_CATEGORIES) {
            System.out.println("- " + category);
        }
    }
    
}
