/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inheritance.kyleo;

/**
 *
 * @author angel
 */
public class Pet {

    private final String petName;
    private final String ownerName;
    private final String color;
    private int genderid;

    public Pet(String name, String ownerName, String color) {
        this.petName = name;
        this.ownerName = ownerName;
        this.color = color;
    }
    
    public String getPetName() {
        return petName;
    }
    public String getOwnerName() {
        return ownerName;
    }
    public String getColor() {
        return color;
    }
    public String getGender() {
        if (genderid == 0) {
            return "male";
        }
        else {
            return "female";
        }
    }
    public void setGender(int genderid) {
        this.genderid = genderid;
    }
    
    @Override
    public String toString() {
        return getPetName() + "owned by " + getOwnerName() + "\nColor:" +
                getColor() + "\nGender: " + getGender();
    }
    
}
