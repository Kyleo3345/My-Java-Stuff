/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package inheritance.kyleo;

/**
 *
 * @author angel
 */
public interface Boardable {

    void setBoardStart(int month, int day, int year);

    void setBoardEnd(int month, int day, int year);

    boolean boarding(int month, int day, int year);
}
