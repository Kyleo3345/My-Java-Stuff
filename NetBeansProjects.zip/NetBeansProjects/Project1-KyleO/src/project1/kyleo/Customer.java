/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project1.kyleo;
import java.util.*;
/**
 *
 * @author angel
 */
public final class Customer {
    private final String fName, lName, email, ID, address, state, Phone;
    private ArrayList<Book> booksBorrowed;
    
    //Constructor//
    public Customer(String fName, String lName, String email, 
            String address, String state, String Phone) {
        this.Phone = Phone;
        this.fName = fName;
        this.lName = lName;
        this.email = email;
        this.address = address;
        this.state = state;
        ID = generateCustomerID();
        
    }
    
    public String getfName() {
        return fName;
    }
    
    public String getlName() {
        return lName;
    }
    
    public String getPhone() {
        return Phone;
    }
    
    public String getAddress() {
        return address;
    }
    
    public String getEmail() {
        return email;
    }
    
    public String getState() {
        return state;
    }
    
    public String getCustomerID() {
        return ID;
    }
    
    public String generateCustomerID() {
        Random rand = new Random();
        char fN = fName.charAt(0);
        char lN = lName.charAt(0);
        int rand_int = rand.nextInt(1000);
        String num = Integer.toString(rand_int);
        System.out.print(fN);
        System.out.print(lN);
        System.out.print(num);
        String generateCustomerID = (fN + lN + num);
        return generateCustomerID;
    }
    
    public void borrowBook(Book book) {
        booksBorrowed.add(book);
    }
    public void returnBook(Book book) {
        booksBorrowed.remove(book);
    }
    
}
