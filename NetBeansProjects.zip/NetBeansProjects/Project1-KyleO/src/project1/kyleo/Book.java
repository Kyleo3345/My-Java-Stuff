/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project1.kyleo;
import java.util.*;
/**
 *
 * @author angel
 */
public class Book {
    private final String title, author, publisher, ISBN;
    private int Qty;
    
    //Constructor//
    public Book(String title, String author, String publisher, String ISBN, int Qty) {
        this.ISBN = ISBN;
        this.Qty = Qty;
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        
    }
    
    public String getTitle() {
        return title;
    }

    public String getAuthorName() {
        return author;
    }
    
    public String getPublisher() {
        return publisher;
    }
    
    public String getISBN() {
        return ISBN;
    }
    
    public int getQty() {
        return Qty;
    }
    
    public void decQty(int Qty) {
        this.Qty = this.Qty -Qty;
    }
    
    public void incQty(int Qty) {
        this.Qty = this.Qty +Qty;
    }
}
