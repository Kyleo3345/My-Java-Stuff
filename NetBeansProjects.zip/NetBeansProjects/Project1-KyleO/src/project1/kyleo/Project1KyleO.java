/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project1.kyleo;
import java.util.*;
/**
 *
 * @author angel
 */
public class Project1KyleO {
    
    public static void main(String[] args) {
        LibrarySimulation LibSim = new LibrarySimulation();
        LibSim.run();
    }
    
}
