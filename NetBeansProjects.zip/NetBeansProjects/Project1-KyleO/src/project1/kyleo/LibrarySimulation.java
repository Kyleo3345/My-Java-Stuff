/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project1.kyleo;
import java.util.*;
/**
 *
 * @author angel
 */
public class LibrarySimulation {
    Scanner scan = new Scanner(System.in);
    Library library = new Library();
    public void run() {
        int choice;
        do {
            displayMenu();
            System.out.print("Enter Action: ");
            choice = scan.nextInt();
            scan.nextLine();
            switch (choice) {
               case 1 -> library.addCustomer();
               case 2 -> library.displayCustomers();
               case 3 -> library.addBook();
               case 4 -> library.displayBooks();
               case 5 -> library.borrowBook();
               case 6 -> library.returnBook();
               case 7 -> {
                   System.out.println("Exiting...");
                   System.exit(0);
                }
               default -> System.out.println("Invalid choice!! Please enter between 1-7.");
           }
        } while (choice != 7);
    }
    //method to display the menu//
    private void displayMenu() {
        System.out.println("\nMain Menu:");
        System.out.println("1. Register New Customer");
        System.out.println("2. Display Customers");
        System.out.println("3. Add New Book");
        System.out.println("4. Display Books");
        System.out.println("5. Borrow Book");
        System.out.println("6. Return Book");
        System.out.println("7. Exit");
    }
}
