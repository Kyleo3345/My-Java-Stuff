/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project1.kyleo;
import java.util.*;
/**
 *
 * @author angel
 */
public class Validation {
    
    public static boolean validCustomerName(String fName, String lName) {
       return fName.length() <= 20 && lName.length() <= 20;
    }
    
    public static boolean validPhoneNumber(String Phone) {
        System.out.println("Phone length: " + Phone.length());
        return Phone.length() <= 10;
    }
    
    public static boolean validAuthor(String author) {
        return author.length() <= 20;
    }
    
    public static boolean validISBN(String ISBN) {
        return ISBN.length() == 10;
    }
    
    public static boolean validEmail(String email) {
        if(!email.contains("@") || !email.contains(".")){
            System.out.println("Email invalid!!");
        } else {
            return true;
        }
        return false;
    }
    
}