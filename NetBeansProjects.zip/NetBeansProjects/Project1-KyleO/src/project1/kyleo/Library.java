/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project1.kyleo;

import java.util.*;

/**
 *
 * @author angel
 */
public class Library {
    private final ArrayList<Book> books;
    private final ArrayList<Customer> customers;
    Scanner scan = new Scanner(System.in);

    public Library() {
        books = new ArrayList<>();
        customers = new ArrayList<>();
    }
    //method to add customers//
    public void addCustomer() {
        
        System.out.println("Enter customer first name: ");
        String fName = scan.nextLine();
        System.out.println("Enter customer last name: ");
        String lName = scan.nextLine();
        System.out.println("Enter customer Email: ");
        String email = scan.nextLine();
        System.out.println("Enter customer Phone: ");
        String Phone = scan.nextLine();
        System.out.println("Enter customer Address: ");
        String address = scan.nextLine();
        System.out.println("Enter customer State: ");
        String state = scan.nextLine();
        
        Customer newCustomer = new Customer(fName, lName, email, address, state, Phone);
        customers.add(newCustomer);
        

    }
    //method to display customers//
    public void displayCustomers() {
        System.out.println("Customers: ");
        for (Customer customer : customers) {
            System.out.println("Name: " + customer.getfName() + " " + customer.getlName());
            System.out.println("Phone: " + customer.getPhone());
            System.out.println("Email: " + customer.getEmail());
            System.out.println("Address: " + customer.getAddress());
            System.out.println("State: " + customer.getState());
            System.out.println("ID: " + customer.getCustomerID());
        }
    }
    //method to add books//
    public void addBook() {
        System.out.println("Enter Book title: ");
        String title = scan.nextLine();
        System.out.println("Enter Book Author: ");
        String author = scan.nextLine();
        System.out.println("Enter Book Publisher: ");
        String publisher = scan.nextLine();
        System.out.println("Enter Book ISBN: ");
        String ISBN = scan.nextLine();
        System.out.println("Enter Book Quantity: ");
        int Qty = scan.nextInt();
        
        Book newBook = new Book(title, author, publisher, ISBN, Qty);
        books.add(newBook);
        System.out.println("Book added!");
    }
    //method to display books//
    public void displayBooks() {
        System.out.println("Books: ");
        for (Book book : books) {
            System.out.println("Title: " + book.getTitle());
            System.out.println("Author: " + book.getAuthorName());
            System.out.println("Publisher: " + book.getPublisher());
            System.out.println("ISBN: " + book.getISBN());
            System.out.println("Qty: " + book.getQty());
        }
    }
    //method for customers to borrow books//
    public void borrowBook() {
        System.out.println("Enter Customer ID: ");
        String ID = scan.nextLine();
        System.out.println("Enter book ISBN to borrow: ");
        String ISBN = scan.nextLine();
        System.out.println("Enter book Quantity: ");
        int Qty = scan.nextInt();
        
        Customer customer = findCustomerByID(ID);
        Book book = findBookByID(ISBN);

        if (customer != null && book != null) {
            System.out.println("Book Borrowed by " + customer.getfName()
                    + customer.getlName());
            customer.borrowBook(book);
            book.decQty(Qty);
        } else if (customer == null) {
            System.out.println("Customer not found!");
        } else {
            System.out.println("Book not found!");
        }
    }
    //method for customers to return books//
    public void returnBook() {
        System.out.println("Enter Customer ID: ");
        String ID = scan.nextLine();
        System.out.println("Enter book ISBN: ");
        String ISBN = scan.nextLine();
        System.out.println("Enter book Quantity: ");
        int Qty = scan.nextInt();
        
        Customer customer = findCustomerByID(ID);
        Book book = findBookByID(ISBN);
        
        if (customer != null && book != null) {
            System.out.println("Book Returned by " + customer.getfName()
                    + customer.getlName());
            customer.returnBook(book);
            book.incQty(Qty);
        } else if (customer == null) {
            System.out.println("Customer not found!");
        } else {
            System.out.println("Book not found!");
        }

    }
    
    public Customer findCustomerByID(String ID) {
        for (Customer customer : customers) {
            if (!customer.getCustomerID().equals(ID)) {
            } else {
                return customer;
            }
        }
        return null;
    }
    public Book findBookByID(String ISBN) {
        for (Book book : books) {
            if (book.getISBN().equals(ISBN)) {
                return book;
            }
        }
        return null;
    }
}
