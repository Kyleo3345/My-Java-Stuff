/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w4.lab.kyleo;

import java.util.*;

/**
 *
 * @author angel
 */
public class W4LabKyleO {

    public static void main(String[] args) {

        String input;
        Character cha;

        Scanner scan = new Scanner(System.in);

        System.out.print("Input string: ");
        input = scan.nextLine();
        
        Set<Character> vowels = new HashSet<>();
        Set<Character> consonants = new HashSet<>();

        for (int i = 0; i < input.length(); i++) {
            cha = Character.toLowerCase(input.charAt(i));
            if (Character.isAlphabetic(cha) == true && 
                    (cha == 'a' || cha == 'e' || cha == 'i' 
                    || cha == 'o' || cha == 'u')) {
                if (vowels.contains(cha) == false) {
                    vowels.add(cha);
                }
                } else {
                    if (Character.isAlphabetic(cha) == true
                            && consonants.contains(cha) == false) {
                        consonants.add(cha);
                    }
                }
            }
            System.out.println("Number of vowels is: " + vowels.size());
            System.out.println("Number of consonants is: " + consonants.size());
        }
}