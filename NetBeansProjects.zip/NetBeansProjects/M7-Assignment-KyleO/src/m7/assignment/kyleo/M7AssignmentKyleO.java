/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package m7.assignment.kyleo;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.regex.*;

/**
*Program: URL Parser
*This: M7AssignmentKyleO.java
*Author: Kyle Osterman
*Date: 20-Mar-2024
 */

public class M7AssignmentKyleO {
    /**
     * @param args the command line arguments
     * @throws java.lang.Exception
     */
    public static void main(String[] args) throws Exception {
         try {
             String baseURL;
             String keyword;
             try (Scanner scan = new Scanner(System.in)) {
                 System.out.print("Enter base URL: ");
                 baseURL = scan.nextLine();
                 System.out.print("Enter search keyword: ");
                 keyword = scan.nextLine();
             }

            URLWrapper baseURLWrapper = new URLWrapper(baseURL);
            baseURLWrapper.findCount(keyword);
            System.out.println("Total occurrences in base URL: " + baseURLWrapper.getCount());

            ArrayList<URLWrapper> innerURLs = baseURLWrapper.extractInnerURLs(keyword);

            // Sort in descending order by count
            Collections.sort(innerURLs, (url1, url2) -> url2.getCount() - url1.getCount());

            // Print to screen and write to file
            try (FileWriter writer = new FileWriter("results.txt")) {
                for (URLWrapper urlWrapper : innerURLs) {
                    String result = urlWrapper.getURL() + " - Count: " + urlWrapper.getCount();
                    System.out.println(result);
                    writer.write(result + "\n");
                    int total = baseURLWrapper.getCount() + 
                            urlWrapper.getCount() + urlWrapper.getCount();
                    System.out.println( "Total = " + total);
                }
                
            }
            
        } catch (IOException e) {
        }
    }
}

 class URLWrapper {
    private final URL url;
    private int count;
    
     public URLWrapper(String urlStr) throws MalformedURLException {
        this.url = new URL(urlStr);
        this.count = 0; // initialize count to 0
    }
     
     protected URL getURL() {
        return this.url;
    }
     protected int getCount() {
        return this.count;
    }
      protected void findCount(String keyword) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()))) {
        String inputLine;
        while ((inputLine = reader.readLine()) != null) {
            while (inputLine.toLowerCase().contains(keyword.toLowerCase())) {
                inputLine = inputLine.substring(inputLine.toLowerCase().indexOf(keyword.toLowerCase()) + keyword.length());
                count++;
            }
        }
    } catch (Exception e) {
    }
    }
      protected ArrayList<URLWrapper> extractInnerURLs(String keyword){
        ArrayList<URLWrapper> innerURLs = new ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()))) {
        String inputLine;
        Pattern pattern = Pattern.compile("href\\s*=\\s*\"((http|https)://.*?)\"", Pattern.CASE_INSENSITIVE);
        while ((inputLine = reader.readLine()) != null) {
            Matcher matcher = pattern.matcher(inputLine);
            while (matcher.find()) {
                String foundURL = matcher.group(1);
                URLWrapper innerURL = new URLWrapper(foundURL);
                innerURL.findCount(keyword);
                if (innerURL.getCount() > 0) {
                    innerURLs.add(innerURL);
                }
            }
        }
    } catch (Exception e) {
    }
    return innerURLs;
    }
     
}



