README

LibrarySimulation class:
The main code of the project. It sets up the code and calls the methods from the other classes like the Library class, Validation class, Customer class, and the Book class.


Library Class:
This class provides the code for the methods for the LibrarySimulation class. Think of this as the background of the LibrarySimulation class. The addCustomer and displayCustomers methods call to the Customer class to provide the information, while the addBook and displayBooks methods call to the Book class, but both borrowBook and returnBook methods call both Customer and Book classes.

Validation Class:
This class validates the data that the user inputs into the system.

