/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package w3.lab.kyleo;

/**
 *
 * @author angel
 * @param <T>
 */
public interface QueueADT<T> {
    public void enqueue(T item);
    public T dequeue();
    public T peek();
}
