/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w3.lab.kyleo;

import java.util.*;

/**
 *
 * @author angel
 */
public class W3LabKyleO {

    public static void main(String[] args) {
        FixedSizeArrayQueue<String> queue = new FixedSizeArrayQueue<>(4);

        queue.enqueue("Car");
        queue.enqueue("Boat");
        queue.enqueue("Plane");

        System.out.println("Size of the queue: " + queue.size());
        System.out.println("Head element: " + queue.peek());

        String item1 = queue.dequeue();
        String item2 = queue.dequeue();

        System.out.println("Dequeued items: " + item1 + ", " + item2);

        queue.enqueue("Walking");

        System.out.println("Is the queue full? " + queue.isFull());

        while (!queue.isEmpty()) {
            System.out.println("Dequeued item: " + queue.dequeue());
        }

        System.out.println("Is the queue empty? " + queue.isEmpty());
    }

}

 class FixedSizeArrayQueue<T> implements QueueADT<T> {

    private final T[] queueArray;
    private int front;
    private int rear;
    private int size;

    public FixedSizeArrayQueue(int capacity) {
        queueArray = (T[]) new Object[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }

    @Override
    public void enqueue(T item) {
        if (isFull()) {
            throw new IllegalStateException("Queue is full. Cannot enqueue item.");
        }

        rear = (rear + 1) % queueArray.length;
        queueArray[rear] = item;
        size++;
    }

    @Override
    public T dequeue() {
        if (isEmpty()) {
            throw new NoSuchElementException("Queue is empty. Cannot dequeue item.");
        }

        T item = queueArray[front];
        front = (front + 1) % queueArray.length;
        size--;
        return item;
    }

    @Override
    public T peek() {
        if (isEmpty()) {
            throw new NoSuchElementException("Queue is empty. Cannot peek item.");
        }

        return queueArray[front];
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean isFull() {
        return size == queueArray.length;
    }

    public int size() {
        return size;
    }

}
