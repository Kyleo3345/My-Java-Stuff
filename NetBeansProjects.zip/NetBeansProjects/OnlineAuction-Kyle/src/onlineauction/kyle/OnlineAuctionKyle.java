/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package onlineauction.kyle;

import java.util.*;

/**
 *
 * @author angel
 */
public class OnlineAuctionKyle {

    public static void main(String[] args) {
        boolean validPrice = false;
        boolean validQuant = false;
        float f = 0;
        int q = 0;

        Scanner scan = new Scanner(System.in);
        while (!validPrice || !validQuant) 
        {
            String price = scan.nextLine();
            String quant = scan.nextLine();
            
            validPrice = validatePrice(price);
            validQuant = validateQuantity(quant);
            if (validPrice != true) {
                continue;
            }
            if (validQuant != true) {
                continue;
            }
            f = Float.parseFloat(price);
            q = Integer.parseInt(quant);
            
        }
        System.out.println("Please type the price you are willing to pay: ");
    }

    public static boolean validatePrice(String input) {
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (ch != '.' && !Character.isDigit(ch)) {
                return false;
            }
        }
        return true;
    }

    public static boolean validateQuantity(String input) {
        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            if (ch != '.' && !Character.isDigit(ch)) {
                return false;
            }
        }
        int qty = Integer.parseInt(input);
        return (qty > 0);
    }
}
