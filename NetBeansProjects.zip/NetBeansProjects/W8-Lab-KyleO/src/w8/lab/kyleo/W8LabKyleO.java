/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w8.lab.kyleo;

/**
 *
 * @author angel
 */
public class W8LabKyleO {
    public static void main(String[] args) {
        DLL DLL = new DLL();
        
        DLL.addNd(1);
        DLL.addNd(2);
        DLL.addNd(3);
        DLL.addNd(4);
        
        System.out.println("Normal Linked List: ");
        DLL.traverseFwd();
        DLL.delLast();
        DLL.addNd(5);
        
        System.out.println("\nModified Linked List: ");
        DLL.traverseFwd();
        DLL.traverseBack();
    }
}

class DLL {
    static class Node {

        int data;
        Node prev, next;

        Node(int data) {
            this.data = data;
            this.next = null;
            this.prev = null;
        }
    }

    private Node head, tail;

    public DLL() {
        this.head = null;
        this.tail = null;
    }

    public void addNd(int data) {
        Node newNd = new Node(data);
        if (head == null) {
            head = tail = newNd;
        } else {
            tail.next = newNd;
            newNd.prev = tail;
            tail = newNd;
        }
    }

    public void delLast() {
        if (tail != null) {
            tail = tail.prev;
            if (tail != null) {
                tail.next = null;
            } else {
                head = null;
            }
        }
    }

    public void traverseFwd() {
        Node current = head;
        System.out.println("Forward Transversal: ");
        while (current != null) {
            System.out.println(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public void traverseBack() {
        Node current = tail;
        System.out.println("Backward Transversal: ");
        while (current != null) {
            System.out.println(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}
