/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package w5.lab.kyleo;

/**
 *
 * @author angel
 */
public interface SetADT {
    void add(int element);
    int remove(int e);
    boolean equals();
    boolean isEmpty();
    int size();
    boolean contains(int e);
}
