/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animal.kyleo;

import java.util.*;
import java.io.*;


public class AnimalBook {
    private ArrayList<Animal> AnimalList;
    
    public AnimalBook(String fileN) {
        AnimalList = new ArrayList<>();
        animalFile(fileN);
    }
    private void animalFile(String fileN) {
        try {
            Scanner scan = new Scanner(new File(fileN));
            while (scan.hasNextLine()) {
                String[] parts = scan.nextLine().split(",");
                String name = parts[0].trim();
                int topSpeed = Integer.parseInt(parts[1].trim());
                AnimalList.add(new Animal(name, topSpeed));
            }
            scan.close();
        } catch (FileNotFoundException e) {
            System.err.println("Error: File not found - " + fileN);
        }
    }
    
    @Override
    public String toString() {
        StringBuilder res = new StringBuilder();
        for (Animal animal : AnimalList) {
            res.append(animal.toString()).append("\n");
        }
        return res.toString();
    }
    public ArrayList<Animal> find(int speed) {
        ArrayList<Animal> found = new ArrayList<>();
        for (Animal animal : AnimalList) {
            if (animal.getTopSpeed() == speed) {
                found.add(animal);
            }
        }
        return found;
    }
}
