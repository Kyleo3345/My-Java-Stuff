/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package animal.kyleo;

/**
 *
 * @author angel
 */
public class AnimalKyleO {
    public static void main(String[] args) {
        AnimalBook animals = new AnimalBook("AnimalList.txt");
        System.out.println(animals);
        animals.find(50);
    }
}
