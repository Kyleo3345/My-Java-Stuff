/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animal.kyleo;

/**
 *
 * @author angel
 */
public class Animal {
    private String name;
    private int topSpeed;
    
    public Animal(String name, int topSpeed) {
        this.name = name;
        setTopSpeed(topSpeed);
    }
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    
    public int getTopSpeed() {
        return topSpeed;
    }
    public void setTopSpeed(int topSpeed) {
        if (topSpeed >= 0 && topSpeed <= 70) {
            this.topSpeed = topSpeed;
        }
        else {
            System.err.println("Error. Top speed must be between 0 and 70");
        }
    }
    
    @Override
    public String toString() {
        return "Animal: " + name + "         " + "Top speed: " + topSpeed + " MPH";
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Animal) {
            Animal other = (Animal) obj;
            return Math.abs(this.topSpeed - other.topSpeed) <= 2;
        }
        return false;
    }
    
}
