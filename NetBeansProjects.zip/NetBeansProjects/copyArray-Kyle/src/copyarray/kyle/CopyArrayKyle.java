/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package copyarray.kyle;

import java.util.*;

public class CopyArrayKyle {
    public static void main(String[] args) {
        
        int sArray[] = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int dArray[] = new int[] {11, 12, 13, 14, 15, 16, 17, 18, 19, 20};
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("src: ");
        for (int i = 0; i < sArray.length; i++) {
            System.out.print(sArray[i] + " ");
        }
        
        System.out.println(" ");
        System.out.println(" ");

        System.out.println("dest: ");
        for (int i = 0; i < dArray.length; i++) {
            System.out.print(dArray[i] + " ");
        }
    }

    public static String copyArray(Scanner scan, char[] vals) {

        System.out.print("Starting point: ");
        int start = scan.nextInt();
        System.out.print("Ending point: ");
        int end = scan.nextInt();
        char[] newChars = getChars(start, end, vals);
        return new String(newChars);
    }

    public static char[] getChars(int start, int end, char[] vals) {
        int sz = end - start;
        char[] result = new char[sz];
        for (int i = 0; i < sz; i++) {
            result[i] = vals[start + i];
        }
        return result;
    }

    public static void copyVals(String s, char[] vals) {
        for (int i = 0; i < s.length(); i++) {
            vals[i] = s.charAt(i);
        }
    }

}
