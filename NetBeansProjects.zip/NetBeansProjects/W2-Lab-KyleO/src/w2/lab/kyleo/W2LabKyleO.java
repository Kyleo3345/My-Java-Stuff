/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w2.lab.kyleo;
import java.util.Scanner;

/**
 *
 * @author angel
 */

public class W2LabKyleO {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for the number of values
        System.out.print("Enter the number of values: ");
        int n = scanner.nextInt();

        // Create an array to store the values
        int[] arr = new int[n];

        // Loop to input the values into the array
        for (int i = 0; i < n; i++) {
            System.out.print("Enter value " + (i + 1) + ": ");
            arr[i] = scanner.nextInt();
        }

        // Print the original array
        System.out.println("Original Array:");
        printArray(arr);

        // Reverse the elements within the array
        reverseArray(arr);

        // Print the reversed array
        System.out.println("Reversed Array:");
        printArray(arr);
    }

    // Method to reverse the elements within the array
    private static void reverseArray(int[] arr) {
        int left = 0;
        int right = arr.length - 1;

        while (left < right) {
            // Swap elements at left and right positions
            int temp = arr[left];
            arr[left] = arr[right];
            arr[right] = temp;
            
            // Move the pointers towards each other
            left++;
            right--;
        }
    }

    // Method to print an array
    private static void printArray(int[] arr) {
        for (int value : arr) {
            System.out.print(value + " ");
        }
        System.out.println(); // Print a newline
    }
}
