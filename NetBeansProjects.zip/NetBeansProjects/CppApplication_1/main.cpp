/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: angel
 *
 * Created on February 4, 2024, 1:26 PM
 */

#include<iostream>

using namespace std;

void copyArray(int inputArray[], int size, int startingPoint, int endPoint, int resultArray[], int size1, int starting1)
 {

    int j = starting1;

    for (int i = startingPoint; i < size && i <= endPoint && j < size1; i++)
 {

        resultArray[j] = inputArray[i];

        j++;

    }

}

void displayArray(int array[], int size)
 {

    for (int i = 0; i < size; ++i)
 {

        cout << array[i] << " ";

    }

    cout << endl;

}

int main()
 {

    int size;

    cout << "Enter size of user Array: ";

    cin >> size;

    int inputArray[size];

    cout << "Enter " << size << " elements of array: ";

    for (int i = 0; i < size; ++i)
 {

        cin >> inputArray[i];

    }

    int resultArray[size];

    copyArray(inputArray, size, 0, size - 1, resultArray, size, 0);

    cout << "Copied array: ";

    displayArray(resultArray, size);

    return 0;

}

