/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w6.lab.kyleo;

/**
 *
 * @author angel
 */
public class W6LabKyleO {
    public static void main(String[] args) {
        MyMap<String, Integer> map = new MyHashMap<>();
        map.put("Dave", 20);
        map.put("Jack", 35);
        map.put("Marry", 52);
        map.put("Erica", 23);
        map.put("Ben", 64);
        
        System.out.println("Entries in map: " + map);
        System.out.println("The age for Dave is: " + map.get("Dave"));
        
        System.out.println("Is Marry in the map? " + map.containsKey("Marry"));
        System.out.println("Is age 30 in the map? " + map.containsValue(30));
        
        map.remove("Ben");
        System.out.println("Entries in map: " + map);
        
        map.clear();
        System.out.println("Entries in map: " + map);
    }
}
