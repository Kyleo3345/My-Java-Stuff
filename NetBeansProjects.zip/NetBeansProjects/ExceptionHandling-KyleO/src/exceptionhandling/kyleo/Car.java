/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exceptionhandling.kyleo;

//class to accept car speed in integer
public class Car {
    private final boolean isAmbulance;
    
    //To determine if vehicle is an ambulance or not.
    public Car(boolean isAmbulance) {
        this.isAmbulance = isAmbulance;
    }

    public boolean isAmbulance() {
        return isAmbulance;
    }
}
