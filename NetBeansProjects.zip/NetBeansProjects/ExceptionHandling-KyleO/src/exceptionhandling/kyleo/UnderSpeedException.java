/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exceptionhandling.kyleo;

//Under Speed limit exception
public class UnderSpeedException extends Exception{
    public UnderSpeedException(String message) {
        super(message);
    }
}
