/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exceptionhandling.kyleo;
import java.util.*;

/**
*Program: ExceptionHandling
*This: ExceptionHandlingKyleO.java
*Author: Kyle Osterman
*Date: 29-Feb-2024
 */
public class ExceptionHandlingKyleO {

    // Main method of running the code
    public static void main(String[] args){
        Driver dr = new Driver("Jack", 89);
        Car cr = new Car(true);
        Police p = new Police();
        
        p.detectSpeed(dr, cr);
    }
    
}
