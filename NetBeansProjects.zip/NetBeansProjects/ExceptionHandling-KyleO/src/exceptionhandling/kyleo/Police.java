/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exceptionhandling.kyleo;

//police class to monitor speed of car
public class Police {
    // function to detect speed of driver and car
    // and throws exceptions accordingly
    public void detectSpeed(Driver d, Car c){
        try {
            if (d.getSpeed() > 80 && c.isAmbulance() == false) {
                throw new OverSpeedException("OverSpeedException: Speed limit exceeded!");
            } else if (d.getSpeed() < 50 && c.isAmbulance() == false) {
                throw new UnderSpeedException("UnderSpeedException: Speed limit is too low!");
            } else if (c.isAmbulance() && c.isAmbulance() == true) {
                throw new EmergencyException("EmergencyException: Ambulance detected!");
            } else {
                System.out.println("Speed within limits. No issues detected.");
            }
        } catch (OverSpeedException | UnderSpeedException | EmergencyException e) {
            System.out.println(e.getMessage());
        }

    }
}
