/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package w10.lab.kyleo;

import java.util.*;

public class W10LabKyleO {
    
    public static <E extends Comparable<E>> 
        void bubbleSort(E[] list) {
            
            boolean NeedPass = true;
        
        for (int p = 1; p < list.length && NeedPass; p++) {
            NeedPass = false;
            for (int k = 0; k < list.length - p; k++) {
                if (list[k].compareTo(list[k + 1]) > 0) {
                    E tem = list[k];
                    list[k] = list[k + 1];
                    list[k + 1] = tem;
                    
                    NeedPass = true;
                }
            }
        }
    }
    
    public static <E> void bubbleSort(E[] list, 
            Comparator<? super E> comparator) {
        
        boolean NeedPass = true;
        for (int t = 1; t < list.length && NeedPass; t++) {
            NeedPass = false;
            for (int g = 0; g < list.length - t; g++) {
                if (comparator.compare(list[g], list[g + 1]) > 0) {
                    E gan = list[g];
                    list[g] = list[g + 1];
                    list[g + 1] = gan;
                    
                    NeedPass = true;
                }
            }
        }
    }
    
    public static void main(String[] args) {
        Integer[] listArray = {3, 9, 2, 12, 7, 24, 30, 12};
        
        bubbleSort(listArray);
        
        printL(listArray);
    }
    
    public static void printL(Object[] list) {
        for (int f = 0; f < list.length; f++)
            System.out.print(list[f] + " ");
        System.out.println();
    }    
}
